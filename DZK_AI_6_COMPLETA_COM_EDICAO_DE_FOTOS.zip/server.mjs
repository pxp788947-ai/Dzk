// Lightweight local server, no npm install required. Vercel runs api/*.js directly.
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import chat from './api/chat.js';
import image from './api/image.js';
import editImage from './api/edit-image.js';
import status from './api/status.js';
const root = dirname(fileURLToPath(import.meta.url));
const routes = new Map([['/api/chat',chat],['/api/image',image],['/api/edit-image',editImage],['/api/status',status]]);
const server = createServer(async (req,res) => {
  const path = new URL(req.url, 'http://localhost').pathname;
  if (routes.has(path)) return routes.get(path)(req,res);
  if (req.method !== 'GET' || (path !== '/' && path !== '/index.html')) {res.writeHead(404);return res.end('Não encontrado.');}
  try {const html=await readFile(join(root,'index.html'));res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(html);}
  catch {res.writeHead(500);res.end('Falha ao carregar HTML.');}
});
const port=Number(process.env.PORT || 3000);
server.listen(port,()=>console.log(`DZK AI: http://localhost:${port}`));
