# DZK AI 6 — Chat e edição de fotos com IA real com modelos de IA

Este projeto substitui as respostas **demonstrativas** da versão HTML anterior por solicitações a uma **API de IA real**. O frontend continua responsivo, com acesso local por nome/e-mail e histórico no navegador. **Não é um login autenticado:** qualquer pessoa pode digitar um e-mail e entrar nesse perfil no mesmo navegador. Não serve para armazenar dados sensíveis de outras pessoas.

## O que funciona após conectar a chave e publicar

- Conversas reais via OpenAI Responses API, com contexto de conversa e código Markdown.
- Potências verdadeiras: Básica → `gpt-6-luna`; Avançada → `gpt-6.1-terra`; Pro → `gpt-6.1-sol`; Ultra → `gpt-6-astra` (depende de acesso e créditos da conta).
- **Enviar foto e Editar foto:** selecione foto JPG/PNG/WebP da galeria, confira prévia, descreva o que mudar e receba imagem editada pela Image Edits API (`gpt-image-2.5-sunburst`). O envio é compactado no navegador e as fotos ficam no histórico local (IndexedDB). Há limite de 2 solicitações/minuto por instância, compartilhado com geração.
- Generate Image via `gpt-image-2.5-flare`, salvo em **IndexedDB do mesmo navegador**. Limite de imagem básico 2 solicitações/minuto por instância.
- Download de código de bloco Markdown em `.lua`, `.js`, `.html` e outros, e download JPEG.
- Histórico de texto via `localStorage` para cada e-mail digitado, **somente no navegador/origem em que foi usado**.
- API key exclusivamente no servidor, nunca exposta em `index.html`.
- Proteção simples por IP, validação de origem e código de acesso opcional.

### Publicar na Vercel

1. Crie um projeto na Vercel importando esta pasta (ou um repositório com os arquivos). Framework: **Other** (sem Next.js). A raiz do projeto deve conter `index.html` e a pasta `api/`.
2. No painel de ambiente da Vercel, adicione **`OPENAI_API_KEY`** com a chave criada no painel OpenAI API. **Não cole a chave em um arquivo HTML, GitHub ou nesta conversa.**
3. Opcionalmente configure `AI_MAX_POWER=Avançada` para impedir uso dos modelos de maior custo, `AI_ACCESS_CODE=SEU_CODIGO` para restringir uso (o botão "Acesso" no site solicita esse código), e `AI_ALLOW_IMAGES=false` para desligar geração e edição de imagens. Opcional: `OPENAI_EDIT_MODEL=gpt-image-2.5-sunburst` para trocar o modelo de edição. Tenha limites de gasto na conta da API.
4. Publique o projeto. Acesse a URL `https://...vercel.app`, **não abra o arquivo HTML via Downloads/content://**, porque este não possui o servidor da API.
5. Abra `/api/status` para verificar `connected:true`. Faça uma pergunta e confirme que veio uma resposta real.

### Testar num computador com Node.js 20+

```sh
npm start
```

Abra `http://localhost:3000`. Configure `OPENAI_API_KEY` como variável de ambiente **antes** de rodar. O servidor Node não lê arquivos `.env` automaticamente. Exemplo apenas no PowerShell:

```powershell
$env:OPENAI_API_KEY = 'SUA_CHAVE'
npm start
```

**Não compartilhe logs, capturas ou arquivos contendo a chave.**

## Importante

- O site é gratuito **para o visitante**, mas o provedor cobra do **proprietário** pelas chamadas de IA e imagens. Não há garantia de uso ilimitado sem custo.
- A proteção por IP em memória não é suficiente para um site popular ou público. Antes de divulgar, adicione autenticação real, cotas persistentes por usuário, limite global de gastos, monitoramento e proteção contra abuso.
- Não existe garantia de que scripts de exploits para jogos funcionem no mapa atual; a IA não executa o jogo nem tem acesso direto à versão interna dele.
- **Não há painel admin sincronizado nem broadcast global nesta versão simplificada**: essas funções exigem banco real e autenticação como no projeto full-stack anterior. O foco aqui é colocar chat real e histórico local em funcionamento com o mínimo de configurações.
- A API foi preparada e testada com chamadas simuladas; chamadas reais à OpenAI dependem de uma chave que não está conectada neste ambiente.

## Como editar uma foto

No site PUBLICADO, toque em **📎 Enviar foto**, escolha uma imagem JPG/PNG/WebP, escreva por exemplo 'troque a cor da camiseta para azul, mantendo o rosto e a pose', e toque em **✦ Editar foto** ou **Enviar**. A foto original e a versão modificada são guardadas no histórico local do navegador (caso o armazenamento esteja disponível). A imagem é enviada ao serviço da OpenAI para edição; o dono do site paga as chamadas de API. O arquivo HTML aberto de Downloads só permite selecionar a foto e ver prévia; não pode editar sem servidor.

Acesso: botões de potência afetam texto, mas a edição de imagens usa o modelo configurado por `OPENAI_EDIT_MODEL`.

Referência oficial: https://developers.openai.com/api/reference/resources/images/methods/edit
