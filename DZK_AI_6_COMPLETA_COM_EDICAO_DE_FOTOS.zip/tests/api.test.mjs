import test, {after} from 'node:test';
import assert from 'node:assert/strict';
import chat from '../api/chat.js';
import image from '../api/image.js';
import editImage from '../api/edit-image.js';
import status from '../api/status.js';

const originalFetch = globalThis.fetch;
const originalKey = process.env.OPENAI_API_KEY;
const originalMax = process.env.AI_MAX_POWER;
const originalImage = process.env.AI_ALLOW_IMAGES;
const originalAccess = process.env.AI_ACCESS_CODE;
let hits=[];
const fakeFetch = async (url,opts) => {
  const request=JSON.parse(opts.body);
  hits.push({url,request,auth:opts.headers.Authorization});
  if(url.endsWith('/responses')) return {ok:true,json:async()=>({model:request.model,output:[{content:[{type:'output_text',text:'Resposta real simulada em teste com ```lua\nprint("ok")\n```'}]}]})};
  if(url.endsWith('/images/edits'))return {ok:true,json:async()=>({data:[{b64_json:'ZWRpdGVk'}]})};
  if(url.endsWith('/images/generations'))return {ok:true,json:async()=>({data:[{b64_json:'dGVzdGU='}]})};
  return {ok:false,status:404,json:async()=>({})};
};
function req(body,ip='1.2.3.4',overrides={}) {return {method:'POST',body,headers:{'content-type':'application/json',host:'dzk.test',origin:'https://dzk.test','x-forwarded-for':ip,...overrides},socket:{remoteAddress:ip}};}
function res(){return {statusCode:200,headers:{},setHeader(k,v){this.headers[k]=v},end(x){this.body=JSON.parse(x)}};}
async function call(fn,body,ip,overrides){const r=res();await fn(req(body,ip,overrides),r);return r;}

after(()=>{globalThis.fetch=originalFetch;for (const [k,v] of [['OPENAI_API_KEY',originalKey],['AI_MAX_POWER',originalMax],['AI_ALLOW_IMAGES',originalImage],['AI_ACCESS_CODE',originalAccess]])if(v===undefined)delete process.env[k];else process.env[k]=v});

test('faltando chave, não gera resposta falsa',async()=>{
  delete process.env.OPENAI_API_KEY;
  globalThis.fetch=fakeFetch;
  const response=await call(chat,{prompt:'Oi',power:'Básica'},'10.11.12.13');
  assert.equal(response.statusCode,503);
  assert.match(response.body.error,/OPENAI_API_KEY/);
});

test('chat chama Responses API com modelo real e contexto, mas sem vazar a chave',async()=>{
  process.env.OPENAI_API_KEY='test-only-secret';globalThis.fetch=fakeFetch;
  hits=[];
  const response=await call(chat,{prompt:'Escreva Lua',power:'Ultra',messages:[{role:'user',text:'Olá'},{role:'assistant',text:'Oi'},{role:'user',text:'Escreva Lua'}]},'10.11.12.14');
  assert.equal(response.statusCode,200);
  assert.equal(response.body.model,'gpt-6-astra');
  assert.equal(hits[0].request.model,'gpt-6-astra');
  assert.equal(hits[0].request.store,false);
  assert.equal(hits[0].request.input.length,3);
  assert.ok(!JSON.stringify(response.body).includes('test-only-secret'));
});

test('potência básica usa Luna e configuração de máximo impede Ultra',async()=>{
  process.env.AI_MAX_POWER='Avançada';hits=[];
  const basic=await call(chat,{prompt:'Olá',power:'Básica'},'10.11.12.15');
  assert.equal(basic.statusCode,200);assert.equal(hits[0].request.model,'gpt-6-luna');
  const ultra=await call(chat,{prompt:'Olá',power:'Ultra'},'10.11.12.16');
  assert.equal(ultra.statusCode,403);
  delete process.env.AI_MAX_POWER;
});

test('bloqueia origens externas e acesso com código incorreto',async()=>{
  const cross=await call(chat,{prompt:'oi'},'10.11.12.17',{origin:'https://site-estranho.tld'});
  assert.equal(cross.statusCode,403);
  process.env.AI_ACCESS_CODE='codigo-temporario-teste';
  const noCode=await call(chat,{prompt:'oi'},'10.11.12.18');
  assert.equal(noCode.statusCode,403);
  const authorized=await call(chat,{prompt:'oi'},'10.11.12.19',{'x-dzk-access-code':'codigo-temporario-teste'});
  assert.equal(authorized.statusCode,200);
  delete process.env.AI_ACCESS_CODE;
});

test('gera imagem usando endpoint dedicado',async()=>{
  const response=await call(image,{prompt:'Ilustração de planeta'},'10.11.12.20');
  assert.equal(response.statusCode,200);
  assert.equal(response.body.image,'data:image/jpeg;base64,dGVzdGU=');
  assert.equal(hits.at(-1).request.model,'gpt-image-2.5-flare');
});

test('status retorna apenas dados públicos, sem chave',async()=>{
  const request={method:'GET',headers:{}};const response=res();await status(request,response);
  assert.equal(response.statusCode,200);
  assert.equal(response.body.connected,true);
  assert.ok(!JSON.stringify(response.body).includes('test-only-secret'));
});


test('edita foto enviando referência base64 para Images Edits API', async()=>{
  process.env.OPENAI_API_KEY='test-only-secret';globalThis.fetch=fakeFetch;hits=[];
  const photo='data:image/jpeg;base64,'+Buffer.from('imagem ficticia').toString('base64');
  const response=await call(editImage,{prompt:'Mude o fundo para azul',image:photo},'10.11.12.21');
  assert.equal(response.statusCode,200);
  assert.equal(response.body.image,'data:image/jpeg;base64,ZWRpdGVk');
  assert.equal(hits[0].url,'https://api.openai.com/v1/images/edits');
  assert.equal(hits[0].request.images[0].image_url,photo);
  assert.equal(hits[0].request.model,'gpt-image-2.5-sunburst');
});

test('não envia fotos inválidas nem aceita imagem sem prompt',async()=>{
  const bad=await call(editImage,{prompt:'Edite',image:'https://outra-coisa.tld'},'10.11.12.22');
  assert.equal(bad.statusCode,400);
  const missing=await call(editImage,{prompt:'',image:'data:image/jpeg;base64,YQ=='},'10.11.12.23');
  assert.equal(missing.statusCode,400);
});
