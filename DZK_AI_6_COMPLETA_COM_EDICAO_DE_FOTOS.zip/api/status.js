import { run, sendJSON } from '../lib/ai.mjs';
export default run(async (req,res) => {
  if (req.method !== 'GET') return sendJSON(res,405,{error:'Use GET.'});
  sendJSON(res,200,{connected: Boolean(process.env.OPENAI_API_KEY), images:process.env.AI_ALLOW_IMAGES !== 'false', login:'local', history:'local'});
});
