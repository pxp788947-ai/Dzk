import { ApiError, callOpenAI, checkAccess, jsonBody, rateLimit, requirePost, run, sendJSON } from '../lib/ai.mjs';

// Accepts one compressed photo as a data URI. Never accepts API keys from browsers.
export default run(async (req, res) => {
  requirePost(req);
  checkAccess(req);
  rateLimit(req, 'image');
  if (process.env.AI_ALLOW_IMAGES === 'false') throw new ApiError('Edição de imagens desativada pelo administrador.', 403);
  const body = await jsonBody(req, 3_800_000);
  const prompt = String(body.prompt || '').trim();
  if (!prompt || prompt.length > 2500) throw new ApiError('Descreva a edição em até 2.500 caracteres.');
  const image = body.image;
  if (typeof image !== 'string' || image.length > 3_200_000 || !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(image))
    throw new ApiError('Envie uma foto JPG, PNG ou WebP de até 2,4 MB após a preparação.');
  // Use OpenAI Image Edits API with a base64 data URL, per the official API spec.
  const result = await callOpenAI('images/edits', {
    model: process.env.OPENAI_EDIT_MODEL || 'gpt-image-2.5-sunburst',
    images: [{image_url:image}],
    prompt,
    n: 1,
    size: 'auto',
    quality: 'high',
    output_format:'jpeg', output_compression:85,
  });
  const b64 = result?.data?.[0]?.b64_json;
  if (!b64) throw new ApiError('A IA não retornou a foto editada.', 502);
  sendJSON(res, 200, {image:`data:image/jpeg;base64,${b64}`, real:true});
});
