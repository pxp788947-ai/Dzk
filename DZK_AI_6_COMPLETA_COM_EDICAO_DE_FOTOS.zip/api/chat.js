import { POWERS, ApiError, callOpenAI, checkAccess, extractText, jsonBody, rateLimit, requirePost, run, sendJSON } from '../lib/ai.mjs';

export default run(async (req, res) => {
  requirePost(req);
  checkAccess(req);
  rateLimit(req, 'chat');
  const body = await jsonBody(req);
  const prompt = String(body.prompt || '').trim();
  if (!prompt || prompt.length > 8000) throw new ApiError('Digite uma mensagem de até 8.000 caracteres.');
  const requested = POWERS[body.power] ? body.power : 'Básica';
  const maximum = process.env.AI_MAX_POWER || 'Ultra';
  const rankings = Object.keys(POWERS);
  if (rankings.indexOf(requested) > rankings.indexOf(maximum))
    throw new ApiError('Essa potência está desativada pelo administrador.', 403);
  const power = POWERS[requested];
  const conversation = Array.isArray(body.messages) ? body.messages.slice(-16) : [];
  const safeMessages = conversation.map(m => ({
    role: m?.role === 'assistant' ? 'assistant' : 'user',
    content: String(m?.text || '').slice(0, 7000),
  })).filter(m => m.content.trim());
  if (!safeMessages.length || safeMessages.at(-1).role !== 'user' || safeMessages.at(-1).content !== prompt)
    safeMessages.push({role:'user',content:prompt});
  const result = await callOpenAI('responses', {
    model: process.env[`OPENAI_MODEL_${requested === 'Básica' ? 'BASIC' : requested === 'Avançada' ? 'ADVANCED' : requested.toUpperCase()}`] || power.model,
    instructions: `Você é DZK AI, assistente de programação, criação de jogos, scripts Luau/Lua, interfaces e sites. Responda normalmente em português brasileiro. Entregue código completo e útil, com blocos Markdown de linguagem. Diferencie Roblox Studio de scripts para executores externos. Não alegue ter testado código em jogos sem testes reais, não invente APIs do jogo. Quando o usuário pedir site, forneça código HTML/CSS/JS utilizável. Não finja ter publicado um site ou gerado um download remoto. Não forneça roubo de senhas, malware, nem invasão de contas.`,
    input: safeMessages,
    max_output_tokens: power.tokens,
    store: false,
  });
  const answer = extractText(result).trim();
  if (!answer) throw new ApiError('A IA não retornou texto. Tente novamente com outra potência.', 502);
  sendJSON(res, 200, {answer, power:requested, model:result.model || power.model, real:true});
});
