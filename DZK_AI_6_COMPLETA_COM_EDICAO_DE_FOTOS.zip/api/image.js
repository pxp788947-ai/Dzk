import { ApiError, callOpenAI, checkAccess, jsonBody, rateLimit, requirePost, run, sendJSON } from '../lib/ai.mjs';

export default run(async (req, res) => {
  requirePost(req);
  checkAccess(req);
  rateLimit(req, 'image');
  if (process.env.AI_ALLOW_IMAGES === 'false') throw new ApiError('Geração de imagens desativada pelo administrador.', 403);
  const body = await jsonBody(req);
  const prompt = String(body.prompt || '').trim();
  if (!prompt || prompt.length > 2500) throw new ApiError('Descreva a imagem em até 2.500 caracteres.');
  const result = await callOpenAI('images/generations', {
    model: process.env.OPENAI_IMAGE_MODEL || 'gpt-image-2.5-flare',
    prompt, n: 1, size: '1024x1024', output_format:'jpeg', output_compression:80,
  });
  const image = result?.data?.[0]?.b64_json;
  if (!image) throw new ApiError('O serviço não retornou a imagem.', 502);
  sendJSON(res, 200, {image: `data:image/jpeg;base64,${image}`, real:true});
});
